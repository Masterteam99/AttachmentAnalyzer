from fastapi import FastAPI, Depends, HTTPException, status, WebSocket, WebSocketDisconnect, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from typing import List, Dict, Any, Optional
import uvicorn
import asyncio
import json
import logging
import os
from datetime import datetime

# Importazioni locali (da implementare)
from .config import settings
from .models import schemas
from .services.movement_analysis_service import MovementAnalysisService
from .services.user_service import get_current_user, UserService
from .utils.dependencies import get_movement_service

# Configurazione logging
logging.basicConfig(level=getattr(logging, settings.LOG_LEVEL))
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Fitness Analyzer API",
    description="API per l'analisi del movimento con ChatGPT come analizzatore centrale",
    version="1.0.0"
)

# Configurazione CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Gestione delle connessioni WebSocket attive
active_connections: Dict[str, WebSocket] = {}

@app.get("/")
async def root():
    return {"message": "Fitness Analyzer API", "version": "1.0.0"}

@app.get("/health")
async def health_check():
    return {"status": "ok", "timestamp": datetime.now().isoformat()}

# Endpoint per l'analisi del movimento
@app.post("/api/movement/sessions/", response_model=schemas.MovementAnalysisSessionResponse)
async def create_movement_analysis_session(
    request: schemas.MovementAnalysisSessionCreate,
    current_user: schemas.User = Depends(get_current_user),
    movement_service: MovementAnalysisService = Depends(get_movement_service)
):
    """Avvia una nuova sessione di analisi del movimento."""
    try:
        result = await movement_service.start_session(
            user_id=current_user.id,
            exercise_hint=request.exercise_hint
        )
        return result
    except Exception as e:
        logger.error(f"Errore nell'avvio della sessione: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Errore nell'avvio della sessione: {str(e)}"
        )

@app.post("/api/movement/sessions/{session_id}/frames/", response_model=schemas.MovementAnalysisFrameResponse)
async def process_movement_frame(
    session_id: str,
    file: UploadFile = File(...),
    current_user: schemas.User = Depends(get_current_user),
    movement_service: MovementAnalysisService = Depends(get_movement_service)
):
    """Processa un singolo frame per l'analisi del movimento."""
    try:
        # Leggi il frame dal file caricato
        contents = await file.read()
        
        # Processa il frame
        result = await movement_service.process_frame(session_id, contents)
        return result
    except Exception as e:
        logger.error(f"Errore nel processamento del frame: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Errore nel processamento del frame: {str(e)}"
        )

@app.post("/api/movement/sessions/{session_id}/complete/", response_model=schemas.MovementAnalysisCompleteResponse)
async def complete_movement_analysis(
    session_id: str,
    current_user: schemas.User = Depends(get_current_user),
    movement_service: MovementAnalysisService = Depends(get_movement_service)
):
    """Completa una sessione di analisi del movimento e genera feedback con ChatGPT."""
    try:
        result = await movement_service.complete_session(session_id)
        return result
    except Exception as e:
        logger.error(f"Errore nel completamento della sessione: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Errore nel completamento della sessione: {str(e)}"
        )

# Endpoint WebSocket per l'analisi in tempo reale
@app.websocket("/ws/movement/{user_id}")
async def websocket_movement_analysis(
    websocket: WebSocket,
    user_id: int,
    movement_service: MovementAnalysisService = Depends(get_movement_service)
):
    await websocket.accept()
    connection_id = f"{user_id}_{datetime.now().timestamp()}"
    active_connections[connection_id] = websocket
    
    try:
        # Ricevi configurazione iniziale
        config_data = await websocket.receive_json()
        exercise_hint = config_data.get("exercise_hint")
        
        # Avvia sessione
        session_result = await movement_service.start_session(user_id, exercise_hint)
        session_id = session_result["session_id"]
        
        await websocket.send_json({
            "type": "session_started",
            "session_id": session_id
        })
        
        # Processa frames
        while True:
            # Ricevi dati frame
            data = await websocket.receive_bytes()
            
            # Processa frame
            result = await movement_service.process_frame(session_id, data)
            
            # Invia risultato
            await websocket.send_json({
                "type": "frame_processed",
                "data": result
            })
            
            # Controlla se il client vuole completare la sessione
            try:
                # Controllo non bloccante per messaggio di completamento
                completion_data = await asyncio.wait_for(
                    websocket.receive_json(),
                    timeout=0.01
                )
                
                if completion_data.get("type") == "complete_session":
                    # Completa sessione e ottieni feedback
                    complete_result = await movement_service.complete_session(session_id)
                    
                    # Invia feedback al client
                    await websocket.send_json({
                        "type": "session_completed",
                        "data": complete_result
                    })
                    
                    # Esci dal loop
                    break
            
            except asyncio.TimeoutError:
                # Nessun messaggio di completamento, continua a processare frames
                pass
                
    except WebSocketDisconnect:
        # Completa sessione alla disconnessione
        try:
            complete_result = await movement_service.complete_session(session_id)
            logger.info(f"WebSocket disconnesso, sessione completata: {session_id}")
        except Exception as e:
            logger.error(f"Errore nel completamento della sessione dopo disconnessione: {e}")
    except Exception as e:
        logger.error(f"Errore nella connessione WebSocket: {e}")
    finally:
        # Rimuovi connessione
        if connection_id in active_connections:
            del active_connections[connection_id]

# Avvio server
if __name__ == "__main__":
    uvicorn.run(
        "api.main:app",
        host=settings.SERVER_HOST,
        port=settings.SERVER_PORT,
        reload=settings.DEBUG
    )
