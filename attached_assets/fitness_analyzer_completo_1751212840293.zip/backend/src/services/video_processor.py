import cv2
import numpy as np
import mediapipe as mp
import time
import math
import logging
from typing import Dict, List, Any, Optional, Tuple

# Configurazione logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class VideoProcessor:
    """
    Classe per processare i frame video con MediaPipe Pose e estrarre keypoints 3D.
    """
    def __init__(self, 
                 model_complexity: int = 2, 
                 min_detection_confidence: float = 0.7,
                 min_tracking_confidence: float = 0.5):
        """
        Inizializza il processore video con MediaPipe Pose.
        
        Args:
            model_complexity: Complessità del modello (0, 1, o 2)
            min_detection_confidence: Confidenza minima per la detection
            min_tracking_confidence: Confidenza minima per il tracking
        """
        self.mp_pose = mp.solutions.pose
        self.mp_drawing = mp.solutions.drawing_utils
        self.mp_drawing_styles = mp.solutions.drawing_styles
        
        self.pose = self.mp_pose.Pose(
            static_image_mode=False,
            model_complexity=model_complexity,
            enable_segmentation=False,
            min_detection_confidence=min_detection_confidence,
            min_tracking_confidence=min_tracking_confidence
        )
        
        logger.info(f"VideoProcessor inizializzato con model_complexity={model_complexity}")
    
    async def process_frame(self, frame_data: bytes) -> Optional[Dict[str, Any]]:
        """
        Processa un singolo frame con MediaPipe Pose.
        
        Args:
            frame_data: Dati binari del frame
            
        Returns:
            Dizionario con keypoints e angoli articolari, o None se nessuna posa rilevata
        """
        try:
            # Converti i dati binari in frame OpenCV
            nparr = np.frombuffer(frame_data, np.uint8)
            frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            if frame is None:
                logger.error("Impossibile decodificare il frame")
                return None
            
            # Converti in RGB per MediaPipe
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            
            # Processa con MediaPipe Pose
            results = self.pose.process(rgb_frame)
            
            if not results.pose_landmarks:
                logger.warning("Nessun landmark rilevato nel frame")
                return None
            
            # Estrai keypoints
            keypoints = self._extract_keypoints(results.pose_landmarks, results.pose_world_landmarks)
            
            # Calcola angoli articolari di base
            angles = self._calculate_basic_angles(keypoints)
            
            # Crea frame con overlay per debug/visualizzazione
            annotated_frame = self._create_annotated_frame(frame, results.pose_landmarks)
            
            return {
                "keypoints": keypoints,
                "calculated_angles": angles,
                "timestamp": time.time(),
                "frame_height": frame.shape[0],
                "frame_width": frame.shape[1],
                # Opzionale: converti il frame annotato in base64 per visualizzazione
                # "annotated_frame_base64": self._frame_to_base64(annotated_frame)
            }
            
        except Exception as e:
            logger.error(f"Errore nel processamento del frame: {e}")
            return None
    
    def _extract_keypoints(self, landmarks, world_landmarks) -> Dict[str, Dict[str, float]]:
        """
        Estrae i keypoints dai landmark MediaPipe.
        
        Args:
            landmarks: Landmark normalizzati (coordinate immagine)
            world_landmarks: Landmark 3D (coordinate mondo)
            
        Returns:
            Dizionario con i keypoints estratti
        """
        keypoints = {}
        
        for idx, landmark in enumerate(landmarks.landmark):
            landmark_name = self.mp_pose.PoseLandmark(idx).name
            
            # Estrai coordinate normalizzate (0-1)
            keypoints[landmark_name] = {
                "x": landmark.x,
                "y": landmark.y,
                "z": landmark.z,
                "visibility": landmark.visibility
            }
            
            # Aggiungi coordinate mondo se disponibili
            if world_landmarks:
                world_landmark = world_landmarks.landmark[idx]
                keypoints[landmark_name].update({
                    "world_x": world_landmark.x,
                    "world_y": world_landmark.y,
                    "world_z": world_landmark.z
                })
        
        return keypoints
    
    def _calculate_basic_angles(self, keypoints: Dict[str, Dict[str, float]]) -> Dict[str, float]:
        """
        Calcola gli angoli articolari di base dai keypoints.
        
        Args:
            keypoints: Dizionario con i keypoints estratti
            
        Returns:
            Dizionario con gli angoli articolari calcolati
        """
        angles = {}
        
        # Calcola angolo ginocchio destro (anca-ginocchio-caviglia)
        if all(k in keypoints for k in ["RIGHT_HIP", "RIGHT_KNEE", "RIGHT_ANKLE"]):
            angles["RIGHT_KNEE"] = self._calculate_angle_3d(
                keypoints["RIGHT_HIP"],
                keypoints["RIGHT_KNEE"],
                keypoints["RIGHT_ANKLE"]
            )
        
        # Calcola angolo ginocchio sinistro (anca-ginocchio-caviglia)
        if all(k in keypoints for k in ["LEFT_HIP", "LEFT_KNEE", "LEFT_ANKLE"]):
            angles["LEFT_KNEE"] = self._calculate_angle_3d(
                keypoints["LEFT_HIP"],
                keypoints["LEFT_KNEE"],
                keypoints["LEFT_ANKLE"]
            )
        
        # Calcola angolo anca destra (spalla-anca-ginocchio)
        if all(k in keypoints for k in ["RIGHT_SHOULDER", "RIGHT_HIP", "RIGHT_KNEE"]):
            angles["RIGHT_HIP"] = self._calculate_angle_3d(
                keypoints["RIGHT_SHOULDER"],
                keypoints["RIGHT_HIP"],
                keypoints["RIGHT_KNEE"]
            )
        
        # Calcola angolo anca sinistra (spalla-anca-ginocchio)
        if all(k in keypoints for k in ["LEFT_SHOULDER", "LEFT_HIP", "LEFT_KNEE"]):
            angles["LEFT_HIP"] = self._calculate_angle_3d(
                keypoints["LEFT_SHOULDER"],
                keypoints["LEFT_HIP"],
                keypoints["LEFT_KNEE"]
            )
        
        # Calcola angolo gomito destro (spalla-gomito-polso)
        if all(k in keypoints for k in ["RIGHT_SHOULDER", "RIGHT_ELBOW", "RIGHT_WRIST"]):
            angles["RIGHT_ELBOW"] = self._calculate_angle_3d(
                keypoints["RIGHT_SHOULDER"],
                keypoints["RIGHT_ELBOW"],
                keypoints["RIGHT_WRIST"]
            )
        
        # Calcola angolo gomito sinistro (spalla-gomito-polso)
        if all(k in keypoints for k in ["LEFT_SHOULDER", "LEFT_ELBOW", "LEFT_WRIST"]):
            angles["LEFT_ELBOW"] = self._calculate_angle_3d(
                keypoints["LEFT_SHOULDER"],
                keypoints["LEFT_ELBOW"],
                keypoints["LEFT_WRIST"]
            )
        
        # Calcola angolo caviglia destra (ginocchio-caviglia-piede)
        if all(k in keypoints for k in ["RIGHT_KNEE", "RIGHT_ANKLE", "RIGHT_FOOT_INDEX"]):
            angles["RIGHT_ANKLE"] = self._calculate_angle_3d(
                keypoints["RIGHT_KNEE"],
                keypoints["RIGHT_ANKLE"],
                keypoints["RIGHT_FOOT_INDEX"]
            )
        
        # Calcola angolo caviglia sinistra (ginocchio-caviglia-piede)
        if all(k in keypoints for k in ["LEFT_KNEE", "LEFT_ANKLE", "LEFT_FOOT_INDEX"]):
            angles["LEFT_ANKLE"] = self._calculate_angle_3d(
                keypoints["LEFT_KNEE"],
                keypoints["LEFT_ANKLE"],
                keypoints["LEFT_FOOT_INDEX"]
            )
        
        # Calcola angolo schiena (media tra spalle-anche-ginocchia)
        if all(k in keypoints for k in ["LEFT_SHOULDER", "RIGHT_SHOULDER", "LEFT_HIP", "RIGHT_HIP"]):
            # Punto medio spalle
            mid_shoulder = {
                "x": (keypoints["LEFT_SHOULDER"]["x"] + keypoints["RIGHT_SHOULDER"]["x"]) / 2,
                "y": (keypoints["LEFT_SHOULDER"]["y"] + keypoints["RIGHT_SHOULDER"]["y"]) / 2,
                "z": (keypoints["LEFT_SHOULDER"]["z"] + keypoints["RIGHT_SHOULDER"]["z"]) / 2
            }
            
            # Punto medio anche
            mid_hip = {
                "x": (keypoints["LEFT_HIP"]["x"] + keypoints["RIGHT_HIP"]["x"]) / 2,
                "y": (keypoints["LEFT_HIP"]["y"] + keypoints["RIGHT_HIP"]["y"]) / 2,
                "z": (keypoints["LEFT_HIP"]["z"] + keypoints["RIGHT_HIP"]["z"]) / 2
            }
            
            # Punto medio ginocchia
            if all(k in keypoints for k in ["LEFT_KNEE", "RIGHT_KNEE"]):
                mid_knee = {
                    "x": (keypoints["LEFT_KNEE"]["x"] + keypoints["RIGHT_KNEE"]["x"]) / 2,
                    "y": (keypoints["LEFT_KNEE"]["y"] + keypoints["RIGHT_KNEE"]["y"]) / 2,
                    "z": (keypoints["LEFT_KNEE"]["z"] + keypoints["RIGHT_KNEE"]["z"]) / 2
                }
                
                angles["BACK"] = self._calculate_angle_3d(mid_shoulder, mid_hip, mid_knee)
        
        return angles
    
    def _calculate_angle_3d(self, p1: Dict[str, float], p2: Dict[str, float], p3: Dict[str, float]) -> float:
        """
        Calcola l'angolo tra tre punti 3D.
        
        Args:
            p1, p2, p3: Punti 3D (p2 è il vertice dell'angolo)
            
        Returns:
            Angolo in gradi
        """
        try:
            # Crea vettori
            v1 = np.array([p1["x"] - p2["x"], p1["y"] - p2["y"], p1["z"] - p2["z"]])
            v2 = np.array([p3["x"] - p2["x"], p3["y"] - p2["y"], p3["z"] - p2["z"]])
            
            # Calcola norme
            v1_norm = np.linalg.norm(v1)
            v2_norm = np.linalg.norm(v2)
            
            if v1_norm == 0 or v2_norm == 0:
                return 0.0
            
            # Calcola vettori unitari
            v1_unit = v1 / v1_norm
            v2_unit = v2 / v2_norm
            
            # Calcola prodotto scalare
            dot_product = np.clip(np.dot(v1_unit, v2_unit), -1.0, 1.0)
            
            # Calcola angolo in radianti e converti in gradi
            angle_rad = np.arccos(dot_product)
            angle_deg = math.degrees(angle_rad)
            
            return angle_deg
            
        except Exception as e:
            logger.error(f"Errore nel calcolo dell'angolo: {e}")
            return 0.0
    
    def _create_annotated_frame(self, frame, landmarks) -> np.ndarray:
        """
        Crea un frame con overlay dei landmark per debug/visualizzazione.
        
        Args:
            frame: Frame originale
            landmarks: Landmark rilevati
            
        Returns:
            Frame con overlay
        """
        annotated_frame = frame.copy()
        
        # Disegna i landmark
        self.mp_drawing.draw_landmarks(
            annotated_frame,
            landmarks,
            self.mp_pose.POSE_CONNECTIONS,
            landmark_drawing_spec=self.mp_drawing_styles.get_default_pose_landmarks_style()
        )
        
        return annotated_frame
    
    def _frame_to_base64(self, frame) -> str:
        """
        Converte un frame in stringa base64 per visualizzazione web.
        
        Args:
            frame: Frame da convertire
            
        Returns:
            Stringa base64
        """
        import base64
        
        _, buffer = cv2.imencode('.jpg', frame)
        return base64.b64encode(buffer).decode('utf-8')
    
    def release(self):
        """Rilascia le risorse."""
        self.pose.close()
        logger.info("VideoProcessor rilasciato")
