import os
import json
import logging
import time
from typing import Dict, List, Any, Optional
from datetime import datetime
import asyncio

from openai import OpenAI, AsyncOpenAI
from openai.types.chat import ChatCompletionMessage

# Configurazione logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ChatGPTAnalyzer:
    """
    Classe per analizzare i dati di movimento utilizzando l'API ChatGPT.
    """
    def __init__(self, 
                 api_key: Optional[str] = None,
                 model: str = "gpt-4",
                 biomechanical_rules_file: Optional[str] = None):
        """
        Inizializza l'analizzatore ChatGPT.
        
        Args:
            api_key: Chiave API OpenAI (se None, usa variabile d'ambiente)
            model: Modello da utilizzare (default: gpt-4)
            biomechanical_rules_file: Percorso del file con le regole biomeccaniche
        """
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY")
        if not self.api_key:
            logger.warning("Nessuna API key OpenAI fornita. L'analisi non funzionerà.")
        
        self.model = model
        self.client = AsyncOpenAI(api_key=self.api_key)
        self.biomechanical_rules = self._load_biomechanical_rules(biomechanical_rules_file)
        
        logger.info(f"ChatGPTAnalyzer inizializzato con modello {model}")
    
    def _load_biomechanical_rules(self, file_path: Optional[str]) -> Dict[str, Any]:
        """
        Carica le regole biomeccaniche da file.
        
        Args:
            file_path: Percorso del file JSON con le regole
            
        Returns:
            Dizionario con le regole biomeccaniche
        """
        if not file_path or not os.path.exists(file_path):
            logger.warning(f"File regole biomeccaniche non trovato: {file_path}. Utilizzo regole predefinite.")
            return self._get_default_rules()
        
        try:
            with open(file_path, 'r') as f:
                rules = json.load(f)
            logger.info(f"Regole biomeccaniche caricate da {file_path}")
            return rules
        except Exception as e:
            logger.error(f"Errore nel caricamento delle regole biomeccaniche: {e}")
            return self._get_default_rules()
    
    def _get_default_rules(self) -> Dict[str, Any]:
        """
        Restituisce le regole biomeccaniche predefinite.
        
        Returns:
            Dizionario con le regole biomeccaniche predefinite
        """
        return {
            "squat": {
                "description": "Un esercizio di forza per gambe e glutei",
                "correct_form": {
                    "knee_angle_range": [70, 100],
                    "hip_angle_range": [50, 80],
                    "ankle_angle_range": [70, 90],
                    "back_angle_range": [45, 60]
                },
                "common_errors": [
                    {
                        "name": "Ginocchia che collassano internamente",
                        "indicators": "Angolo tra anca-ginocchio-caviglia < 165 gradi",
                        "feedback": "Mantieni le ginocchia allineate con i piedi, spingendole leggermente verso l'esterno"
                    },
                    {
                        "name": "Schiena inarcata",
                        "indicators": "Angolo tra spalla-anca-ginocchio < 145 gradi",
                        "feedback": "Mantieni la schiena in posizione neutra, attivando i muscoli addominali"
                    },
                    {
                        "name": "Profondità insufficiente",
                        "indicators": "Angolo del ginocchio > 100 gradi nel punto più basso",
                        "feedback": "Scendi più in basso, idealmente fino a quando le cosce sono parallele al pavimento"
                    }
                ]
            },
            "push_up": {
                "description": "Un esercizio per pettorali, spalle e tricipiti",
                "correct_form": {
                    "elbow_angle_range": [70, 110],
                    "shoulder_angle_range": [30, 45],
                    "body_alignment": "Testa, spalle, anche e caviglie allineate"
                },
                "common_errors": [
                    {
                        "name": "Schiena inarcata",
                        "indicators": "Anche più basse rispetto alle spalle e alle caviglie",
                        "feedback": "Mantieni il corpo in una linea retta, attivando i muscoli addominali e glutei"
                    },
                    {
                        "name": "Gomiti troppo aperti",
                        "indicators": "Angolo tra spalla-gomito-polso > 45 gradi rispetto al corpo",
                        "feedback": "Mantieni i gomiti più vicini al corpo, formando un angolo di circa 45 gradi"
                    }
                ]
            },
            "lunge": {
                "description": "Un esercizio per gambe, glutei e core",
                "correct_form": {
                    "front_knee_angle_range": [85, 100],
                    "back_knee_angle_range": [85, 100],
                    "torso_angle": "Verticale"
                },
                "common_errors": [
                    {
                        "name": "Ginocchio anteriore oltre la punta del piede",
                        "indicators": "Ginocchio anteriore proiettato oltre la punta del piede",
                        "feedback": "Assicurati che il ginocchio anteriore sia allineato con la caviglia, non oltre la punta del piede"
                    },
                    {
                        "name": "Torso inclinato in avanti",
                        "indicators": "Angolo del torso < 80 gradi rispetto al suolo",
                        "feedback": "Mantieni il torso eretto e verticale durante tutto il movimento"
                    }
                ]
            }
        }
    
    async def analyze_movement(self, 
                              movement_data: Dict[str, Any], 
                              exercise_hint: Optional[str] = None) -> Dict[str, Any]:
        """
        Analizza i dati di movimento utilizzando ChatGPT.
        
        Args:
            movement_data: Dati di movimento estratti da MediaPipe
            exercise_hint: Suggerimento sul tipo di esercizio (opzionale)
            
        Returns:
            Dizionario con il feedback generato
        """
        # Prepara il prompt con i dati di movimento e le regole pertinenti
        prompt = self._create_prompt(movement_data, exercise_hint)
        
        try:
            # Chiama l'API ChatGPT
            start_time = time.time()
            response = await self._call_openai_api(prompt)
            elapsed_time = time.time() - start_time
            
            logger.info(f"Analisi ChatGPT completata in {elapsed_time:.2f} secondi")
            
            # Processa e struttura la risposta
            structured_feedback = self._structure_feedback(response)
            
            return {
                "feedback": structured_feedback,
                "raw_response": response,
                "generated_at": datetime.now().isoformat(),
                "processing_time": elapsed_time
            }
        except Exception as e:
            logger.error(f"Errore nella chiamata all'API OpenAI: {e}")
            return {
                "feedback": {
                    "exercise_identified": "unknown",
                    "is_correct": None,
                    "errors_detected": [],
                    "feedback": f"Impossibile generare feedback al momento. Errore: {str(e)}",
                    "suggestions": []
                },
                "error": str(e),
                "generated_at": datetime.now().isoformat()
            }
    
    def _create_prompt(self, 
                      movement_data: Dict[str, Any], 
                      exercise_hint: Optional[str] = None) -> str:
        """
        Crea un prompt strutturato per ChatGPT.
        
        Args:
            movement_data: Dati di movimento estratti
            exercise_hint: Suggerimento sul tipo di esercizio
            
        Returns:
            Prompt strutturato per ChatGPT
        """
        # Estrai keypoints e angoli calcolati
        keypoints = movement_data.get("keypoints", {})
        angles = movement_data.get("calculated_angles", {})
        
        # Inizia a costruire il prompt
        prompt = """
        Sei un esperto di biomeccanica e analisi del movimento. Analizza i seguenti dati di movimento estratti tramite MediaPipe:
        
        Keypoints principali (coordinate normalizzate x, y, z):
        """
        
        # Aggiungi dati dei keypoints principali (limita per risparmiare token)
        important_keypoints = [
            "NOSE", "LEFT_SHOULDER", "RIGHT_SHOULDER", "LEFT_ELBOW", "RIGHT_ELBOW",
            "LEFT_WRIST", "RIGHT_WRIST", "LEFT_HIP", "RIGHT_HIP", "LEFT_KNEE",
            "RIGHT_KNEE", "LEFT_ANKLE", "RIGHT_ANKLE", "LEFT_FOOT_INDEX", "RIGHT_FOOT_INDEX"
        ]
        
        for kp_name in important_keypoints:
            if kp_name in keypoints:
                kp = keypoints[kp_name]
                prompt += f"- {kp_name}: x={kp['x']:.2f}, y={kp['y']:.2f}, z={kp['z']:.2f}, vis={kp['visibility']:.2f}\n"
        
        prompt += "\nAngoli articolari calcolati:\n"
        
        for joint, angle in angles.items():
            prompt += f"- {joint}: {angle:.1f} gradi\n"
        
        # Aggiungi suggerimento sull'esercizio se fornito
        if exercise_hint:
            prompt += f"\nSuggerimento: L'utente potrebbe star eseguendo un {exercise_hint}.\n"
        
        # Aggiungi regole biomeccaniche pertinenti
        prompt += "\nUtilizza queste regole biomeccaniche di base come riferimento:\n"
        
        # Se abbiamo un suggerimento, aggiungi regole specifiche, altrimenti aggiungi regole generali
        if exercise_hint and exercise_hint.lower() in self.biomechanical_rules:
            rules = self.biomechanical_rules[exercise_hint.lower()]
            prompt += json.dumps(rules, indent=2)
        else:
            # Aggiungi un sottoinsieme di regole per esercizi comuni
            common_exercises = ["squat", "push_up", "lunge"]
            for ex in common_exercises:
                if ex in self.biomechanical_rules:
                    prompt += f"\n{ex.upper()}:\n"
                    prompt += json.dumps(self.biomechanical_rules[ex], indent=2)
        
        prompt += """
        
        Per favore:
        1. Identifica di quale esercizio si tratta basandoti sui pattern di movimento
        2. Valuta se il movimento è eseguito correttamente
        3. Identifica eventuali errori o problemi nella forma
        4. Fornisci feedback correttivi specifici
        5. Suggerisci modifiche per migliorare l'esecuzione
        
        Rispondi in formato JSON con i seguenti campi:
        {
          "exercise_identified": "nome dell'esercizio",
          "is_correct": true/false,
          "errors_detected": ["errore 1", "errore 2", ...],
          "feedback": "feedback dettagliato",
          "suggestions": ["suggerimento 1", "suggerimento 2", ...]
        }
        """
        
        return prompt
    
    async def _call_openai_api(self, prompt: str) -> str:
        """
        Chiama l'API OpenAI con il prompt specificato.
        
        Args:
            prompt: Prompt strutturato per ChatGPT
            
        Returns:
            Risposta testuale dall'API
        """
        try:
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "Sei un esperto di biomeccanica e allenamento. Fornisci feedback precisi e utili sulla tecnica di esecuzione degli esercizi."},
                    {"role": "user", "content": prompt}
                ],
                response_format={"type": "json_object"},
                max_tokens=1000,
                temperature=0.5  # Ridotta per risposte più deterministiche
            )
            
            return response.choices[0].message.content
        except Exception as e:
            logger.error(f"Errore nella chiamata all'API OpenAI: {e}")
            raise
    
    def _structure_feedback(self, response_text: str) -> Dict[str, Any]:
        """
        Struttura il feedback dalla risposta di ChatGPT.
        
        Args:
            response_text: Risposta testuale dall'API
            
        Returns:
            Feedback strutturato
        """
        try:
            # Analizza la risposta JSON
            feedback_data = json.loads(response_text)
            
            # Verifica che tutti i campi necessari siano presenti
            required_fields = ["exercise_identified", "is_correct", "errors_detected", "feedback", "suggestions"]
            for field in required_fields:
                if field not in feedback_data:
                    feedback_data[field] = None if field == "is_correct" else []
            
            return feedback_data
        except json.JSONDecodeError as e:
            logger.error(f"Errore nella decodifica JSON: {e}")
            # Fallback se la risposta non è JSON valido
            return {
                "exercise_identified": "unknown",
                "is_correct": None,
                "errors_detected": [],
                "feedback": response_text,
                "suggestions": []
            }
        except Exception as e:
            logger.error(f"Errore nella strutturazione del feedback: {e}")
            return {
                "exercise_identified": "unknown",
                "is_correct": None,
                "errors_detected": [],
                "feedback": "Errore nell'elaborazione del feedback.",
                "suggestions": []
            }
