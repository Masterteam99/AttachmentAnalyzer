import os
import csv
import json
import logging
import asyncio
from typing import Dict, List, Any, Optional
from datetime import datetime
import numpy as np
import cv2

from sqlalchemy.orm import Session
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update

from ..models import database as models
from ..services.video_processor import VideoProcessor
from ..services.chatgpt_analyzer import ChatGPTAnalyzer
from ..config import settings

# Configurazione logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class MovementAnalysisService:
    """
    Servizio principale per l'analisi del movimento che integra VideoProcessor e ChatGPTAnalyzer.
    """
    def __init__(self, 
                 db_session: Optional[AsyncSession] = None,
                 openai_api_key: Optional[str] = None,
                 biomechanical_rules_file: Optional[str] = None):
        """
        Inizializza il servizio di analisi del movimento.
        
        Args:
            db_session: Sessione database asincrona
            openai_api_key: Chiave API OpenAI
            biomechanical_rules_file: Percorso del file con le regole biomeccaniche
        """
        self.db_session = db_session
        self.video_processor = VideoProcessor(
            model_complexity=settings.MEDIAPIPE_MODEL_COMPLEXITY,
            min_detection_confidence=settings.MEDIAPIPE_MIN_DETECTION_CONFIDENCE,
            min_tracking_confidence=settings.MEDIAPIPE_MIN_TRACKING_CONFIDENCE
        )
        self.chatgpt_analyzer = ChatGPTAnalyzer(
            api_key=openai_api_key or settings.OPENAI_API_KEY,
            model=settings.OPENAI_MODEL,
            biomechanical_rules_file=biomechanical_rules_file or settings.BIOMECHANICAL_RULES_FILE
        )
        
        # Sessioni attive
        self.active_sessions: Dict[str, Dict[str, Any]] = {}
        
        logger.info("MovementAnalysisService inizializzato")
    
    async def start_session(self, user_id: int, exercise_hint: Optional[str] = None) -> Dict[str, Any]:
        """
        Avvia una nuova sessione di analisi del movimento.
        
        Args:
            user_id: ID dell'utente
            exercise_hint: Suggerimento sul tipo di esercizio (opzionale)
            
        Returns:
            Dizionario con informazioni sulla sessione creata
        """
        # Genera ID sessione unico
        session_id = f"{user_id}_{int(datetime.now().timestamp())}"
        
        # Inizializza sessione
        self.active_sessions[session_id] = {
            "user_id": user_id,
            "exercise_hint": exercise_hint,
            "start_time": datetime.now(),
            "frames": []
        }
        
        # Salva sessione nel database se disponibile
        if self.db_session:
            try:
                # Crea nuova sessione nel database
                db_session = models.MovementAnalysisSession(
                    session_id=session_id,
                    user_id=user_id,
                    exercise_hint=exercise_hint
                )
                self.db_session.add(db_session)
                await self.db_session.commit()
                logger.info(f"Sessione {session_id} salvata nel database")
            except Exception as e:
                logger.error(f"Errore nel salvataggio della sessione nel database: {e}")
                await self.db_session.rollback()
        
        logger.info(f"Nuova sessione avviata: {session_id}")
        return {"session_id": session_id}
    
    async def process_frame(self, session_id: str, frame_data: bytes) -> Dict[str, Any]:
        """
        Processa un singolo frame per la sessione specificata.
        
        Args:
            session_id: ID della sessione
            frame_data: Dati binari del frame
            
        Returns:
            Dizionario con risultati dell'analisi del frame
        """
        # Verifica che la sessione esista
        if session_id not in self.active_sessions:
            logger.error(f"Sessione non trovata: {session_id}")
            return {"error": "Sessione non trovata"}
        
        session = self.active_sessions[session_id]
        
        try:
            # Processa frame con MediaPipe
            frame_result = await self.video_processor.process_frame(frame_data)
            
            if not frame_result:
                logger.warning(f"Nessuna posa rilevata nel frame per la sessione {session_id}")
                return {"error": "Nessuna posa rilevata"}
            
            # Aggiungi indice frame
            frame_index = len(session["frames"])
            frame_result["frame_index"] = frame_index
            
            # Salva nel database se disponibile
            if self.db_session:
                try:
                    # Crea nuovo frame nel database
                    db_frame = models.MovementAnalysisFrame(
                        session_id=session_id,
                        timestamp=frame_result["timestamp"],
                        frame_index=frame_index,
                        keypoints=frame_result["keypoints"],
                        calculated_angles=frame_result["calculated_angles"]
                    )
                    self.db_session.add(db_frame)
                    await self.db_session.commit()
                except Exception as e:
                    logger.error(f"Errore nel salvataggio del frame nel database: {e}")
                    await self.db_session.rollback()
            
            # Salva nella sessione
            session["frames"].append(frame_result)
            
            # Aggiorna contatore frame nella sessione database
            if self.db_session:
                try:
                    stmt = (
                        update(models.MovementAnalysisSession)
                        .where(models.MovementAnalysisSession.session_id == session_id)
                        .values(frame_count=len(session["frames"]))
                    )
                    await self.db_session.execute(stmt)
                    await self.db_session.commit()
                except Exception as e:
                    logger.error(f"Errore nell'aggiornamento del contatore frame: {e}")
                    await self.db_session.rollback()
            
            return {
                "session_id": session_id,
                "frame_processed": True,
                "frame_index": frame_index,
                "keypoints_count": len(frame_result["keypoints"])
            }
            
        except Exception as e:
            logger.error(f"Errore nel processamento del frame: {e}")
            return {"error": f"Errore nel processamento del frame: {str(e)}"}
    
    async def complete_session(self, session_id: str) -> Dict[str, Any]:
        """
        Completa una sessione di analisi e genera feedback con ChatGPT.
        
        Args:
            session_id: ID della sessione
            
        Returns:
            Dizionario con risultati completi dell'analisi
        """
        # Verifica che la sessione esista
        if session_id not in self.active_sessions:
            logger.error(f"Sessione non trovata: {session_id}")
            return {"error": "Sessione non trovata"}
        
        session = self.active_sessions[session_id]
        
        try:
            # Verifica che ci siano frame da analizzare
            if not session["frames"]:
                logger.warning(f"Nessun frame catturato nella sessione {session_id}")
                return {"error": "Nessun frame catturato nella sessione"}
            
            # Seleziona frame rappresentativo per l'analisi
            # Per semplicità, usiamo il frame centrale
            middle_idx = len(session["frames"]) // 2
            representative_frame = session["frames"][middle_idx]
            
            # Analizza con ChatGPT
            logger.info(f"Avvio analisi ChatGPT per la sessione {session_id}")
            analysis_result = await self.chatgpt_analyzer.analyze_movement(
                representative_frame,
                exercise_hint=session.get("exercise_hint")
            )
            
            # Estrai feedback strutturato
            feedback = analysis_result.get("feedback", {})
            
            # Salva dati su file
            csv_file = await self._save_to_csv(session_id, session["user_id"], session["frames"])
            json_file = await self._save_feedback_to_json(session_id, session["user_id"], analysis_result)
            
            # Aggiorna sessione nel database
            if self.db_session:
                try:
                    # Aggiorna sessione con risultati dell'analisi
                    stmt = (
                        update(models.MovementAnalysisSession)
                        .where(models.MovementAnalysisSession.session_id == session_id)
                        .values(
                            end_time=datetime.now(),
                            exercise_identified=feedback.get("exercise_identified"),
                            is_correct=feedback.get("is_correct"),
                            errors_detected=feedback.get("errors_detected"),
                            feedback_text=feedback.get("feedback"),
                            suggestions=feedback.get("suggestions"),
                            processing_time=analysis_result.get("processing_time"),
                            csv_file_path=csv_file,
                            json_file_path=json_file
                        )
                    )
                    await self.db_session.execute(stmt)
                    await self.db_session.commit()
                    logger.info(f"Sessione {session_id} aggiornata nel database")
                except Exception as e:
                    logger.error(f"Errore nell'aggiornamento della sessione nel database: {e}")
                    await self.db_session.rollback()
            
            # Prepara risultato completo
            complete_result = {
                "session_id": session_id,
                "user_id": session["user_id"],
                "duration": (datetime.now() - session["start_time"]).total_seconds(),
                "frame_count": len(session["frames"]),
                "exercise_identified": feedback.get("exercise_identified", "unknown"),
                "is_correct": feedback.get("is_correct"),
                "errors_detected": feedback.get("errors_detected", []),
                "feedback": feedback.get("feedback", ""),
                "suggestions": feedback.get("suggestions", []),
                "files": {
                    "csv": csv_file,
                    "json": json_file
                }
            }
            
            # Pulisci
            del self.active_sessions[session_id]
            
            logger.info(f"Sessione {session_id} completata con successo")
            return complete_result
            
        except Exception as e:
            logger.error(f"Errore nel completamento della sessione: {e}")
            return {"error": f"Errore nel completamento della sessione: {str(e)}"}
    
    async def _save_to_csv(self, session_id: str, user_id: int, frames: List[Dict[str, Any]]) -> str:
        """
        Salva i dati dei frame in un file CSV.
        
        Args:
            session_id: ID della sessione
            user_id: ID dell'utente
            frames: Lista dei frame da salvare
            
        Returns:
            Percorso del file CSV salvato
        """
        # Crea directory se non esiste
        data_dir = os.path.join(settings.DATA_DIR, str(user_id), session_id)
        os.makedirs(data_dir, exist_ok=True)
        
        # Determina nome file
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = os.path.join(data_dir, f"movement_data_{timestamp}.csv")
        
        try:
            # Scrivi su CSV
            with open(filename, 'w', newline='') as csvfile:
                # Determina campi
                keypoints = frames[0]["keypoints"] if frames else {}
                angles = frames[0]["calculated_angles"] if frames else {}
                
                fieldnames = ['frame_index', 'timestamp', 'landmark', 'x', 'y', 'z', 'visibility']
                angle_fields = list(angles.keys())
                fieldnames.extend(angle_fields)
                
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                writer.writeheader()
                
                # Scrivi dati
                for frame in frames:
                    frame_index = frame.get("frame_index", 0)
                    timestamp = frame.get("timestamp", 0)
                    keypoints = frame.get("keypoints", {})
                    angles = frame.get("calculated_angles", {})
                    
                    for landmark_name, landmark_data in keypoints.items():
                        row = {
                            'frame_index': frame_index,
                            'timestamp': timestamp,
                            'landmark': landmark_name,
                            'x': landmark_data.get("x"),
                            'y': landmark_data.get("y"),
                            'z': landmark_data.get("z"),
                            'visibility': landmark_data.get("visibility")
                        }
                        
                        # Aggiungi angoli
                        for angle_name, angle_value in angles.items():
                            row[angle_name] = angle_value
                        
                        writer.writerow(row)
            
            logger.info(f"Dati salvati in {filename}")
            return filename
            
        except Exception as e:
            logger.error(f"Errore nel salvataggio dei dati in CSV: {e}")
            return ""
    
    async def _save_feedback_to_json(self, session_id: str, user_id: int, feedback_data: Dict[str, Any]) -> str:
        """
        Salva il feedback in un file JSON.
        
        Args:
            session_id: ID della sessione
            user_id: ID dell'utente
            feedback_data: Dati del feedback
            
        Returns:
            Percorso del file JSON salvato
        """
        # Crea directory se non esiste
        data_dir = os.path.join(settings.DATA_DIR, str(user_id), session_id)
        os.makedirs(data_dir, exist_ok=True)
        
        # Determina nome file
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = os.path.join(data_dir, f"feedback_{timestamp}.json")
        
        try:
            # Scrivi su JSON
            with open(filename, 'w') as jsonfile:
                json.dump(feedback_data, jsonfile, indent=2)
            
            logger.info(f"Feedback salvato in {filename}")
            return filename
            
        except Exception as e:
            logger.error(f"Errore nel salvataggio del feedback in JSON: {e}")
            return ""
    
    def release(self):
        """Rilascia le risorse."""
        self.video_processor.release()
        logger.info("MovementAnalysisService rilasciato")
