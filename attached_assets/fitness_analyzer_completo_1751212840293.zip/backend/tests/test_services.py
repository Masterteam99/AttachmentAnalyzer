import unittest
import asyncio
import os
import json
import tempfile
from unittest.mock import patch, MagicMock

import cv2
import numpy as np

from src.services.video_processor import VideoProcessor
from src.services.chatgpt_analyzer import ChatGPTAnalyzer
from src.services.movement_analysis_service import MovementAnalysisService

class TestVideoProcessor(unittest.TestCase):
    """Test per il modulo VideoProcessor."""
    
    def setUp(self):
        """Inizializza l'ambiente di test."""
        self.video_processor = VideoProcessor(
            model_complexity=1,  # Usa complessità ridotta per i test
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5
        )
        
        # Crea un'immagine di test con una persona in posa
        self.test_image = np.zeros((480, 640, 3), dtype=np.uint8)
        # Disegna una forma umanoide semplice per i test
        cv2.rectangle(self.test_image, (300, 100), (340, 140), (255, 255, 255), -1)  # Testa
        cv2.rectangle(self.test_image, (310, 140), (330, 300), (255, 255, 255), -1)  # Corpo
        cv2.rectangle(self.test_image, (270, 180), (310, 240), (255, 255, 255), -1)  # Braccio sinistro
        cv2.rectangle(self.test_image, (330, 180), (370, 240), (255, 255, 255), -1)  # Braccio destro
        cv2.rectangle(self.test_image, (310, 300), (320, 400), (255, 255, 255), -1)  # Gamba sinistra
        cv2.rectangle(self.test_image, (320, 300), (330, 400), (255, 255, 255), -1)  # Gamba destra
        
        # Converti in bytes per simulare i dati ricevuti dal frontend
        _, self.test_image_bytes = cv2.imencode('.jpg', self.test_image)
        self.test_image_bytes = self.test_image_bytes.tobytes()
    
    def tearDown(self):
        """Pulisce l'ambiente dopo i test."""
        self.video_processor.release()
    
    @patch('mediapipe.solutions.pose.Pose.process')
    async def test_process_frame_with_mock(self, mock_process):
        """Testa il processamento di un frame con mock di MediaPipe."""
        # Configura il mock per simulare il rilevamento di una posa
        mock_landmarks = MagicMock()
        mock_landmarks.landmark = [MagicMock() for _ in range(33)]  # MediaPipe Pose ha 33 landmark
        
        for i, landmark in enumerate(mock_landmarks.landmark):
            landmark.x = 0.5  # Valore normalizzato al centro
            landmark.y = 0.5
            landmark.z = 0.0
            landmark.visibility = 0.9
        
        mock_results = MagicMock()
        mock_results.pose_landmarks = mock_landmarks
        mock_results.pose_world_landmarks = mock_landmarks
        
        mock_process.return_value = mock_results
        
        # Processa il frame
        result = await self.video_processor.process_frame(self.test_image_bytes)
        
        # Verifica che il risultato contenga i dati attesi
        self.assertIsNotNone(result)
        self.assertIn('keypoints', result)
        self.assertIn('calculated_angles', result)
        self.assertIn('timestamp', result)
        
        # Verifica che ci siano 33 keypoints (numero di landmark in MediaPipe Pose)
        self.assertEqual(len(result['keypoints']), 33)
        
        # Verifica che gli angoli siano stati calcolati
        self.assertGreater(len(result['calculated_angles']), 0)
    
    async def test_process_frame_real(self):
        """Testa il processamento di un frame reale (opzionale, può fallire senza GPU)."""
        try:
            # Processa il frame
            result = await self.video_processor.process_frame(self.test_image_bytes)
            
            # Se MediaPipe non rileva una posa nell'immagine di test, il test è inconcludente
            if result is None:
                self.skipTest("MediaPipe non ha rilevato una posa nell'immagine di test")
            
            # Verifica che il risultato contenga i dati attesi
            self.assertIn('keypoints', result)
            self.assertIn('calculated_angles', result)
            self.assertIn('timestamp', result)
            
        except Exception as e:
            self.skipTest(f"Test saltato a causa di errore: {e}")


class TestChatGPTAnalyzer(unittest.TestCase):
    """Test per il modulo ChatGPTAnalyzer."""
    
    def setUp(self):
        """Inizializza l'ambiente di test."""
        # Crea un file temporaneo con regole biomeccaniche di test
        self.temp_rules_file = tempfile.NamedTemporaryFile(delete=False, mode='w', suffix='.json')
        json.dump({
            "squat": {
                "description": "Un esercizio di forza per gambe e glutei",
                "correct_form": {
                    "knee_angle_range": [70, 100],
                    "hip_angle_range": [50, 80]
                },
                "common_errors": [
                    {
                        "name": "Ginocchia che collassano internamente",
                        "indicators": "Angolo tra anca-ginocchio-caviglia < 165 gradi",
                        "feedback": "Mantieni le ginocchia allineate con i piedi"
                    }
                ]
            }
        }, self.temp_rules_file)
        self.temp_rules_file.close()
        
        # Inizializza l'analizzatore con il file di regole temporaneo
        self.chatgpt_analyzer = ChatGPTAnalyzer(
            api_key="test_key",  # Chiave fittizia per i test
            model="gpt-4",
            biomechanical_rules_file=self.temp_rules_file.name
        )
        
        # Dati di movimento di test
        self.test_movement_data = {
            "keypoints": {
                "NOSE": {"x": 0.5, "y": 0.2, "z": 0.0, "visibility": 0.9},
                "LEFT_SHOULDER": {"x": 0.4, "y": 0.3, "z": 0.0, "visibility": 0.9},
                "RIGHT_SHOULDER": {"x": 0.6, "y": 0.3, "z": 0.0, "visibility": 0.9},
                "LEFT_ELBOW": {"x": 0.3, "y": 0.4, "z": 0.0, "visibility": 0.9},
                "RIGHT_ELBOW": {"x": 0.7, "y": 0.4, "z": 0.0, "visibility": 0.9},
                "LEFT_WRIST": {"x": 0.3, "y": 0.5, "z": 0.0, "visibility": 0.9},
                "RIGHT_WRIST": {"x": 0.7, "y": 0.5, "z": 0.0, "visibility": 0.9},
                "LEFT_HIP": {"x": 0.45, "y": 0.6, "z": 0.0, "visibility": 0.9},
                "RIGHT_HIP": {"x": 0.55, "y": 0.6, "z": 0.0, "visibility": 0.9},
                "LEFT_KNEE": {"x": 0.4, "y": 0.8, "z": 0.0, "visibility": 0.9},
                "RIGHT_KNEE": {"x": 0.6, "y": 0.8, "z": 0.0, "visibility": 0.9},
                "LEFT_ANKLE": {"x": 0.4, "y": 0.95, "z": 0.0, "visibility": 0.9},
                "RIGHT_ANKLE": {"x": 0.6, "y": 0.95, "z": 0.0, "visibility": 0.9}
            },
            "calculated_angles": {
                "LEFT_KNEE": 85.0,
                "RIGHT_KNEE": 85.0,
                "LEFT_HIP": 60.0,
                "RIGHT_HIP": 60.0,
                "BACK": 80.0
            }
        }
    
    def tearDown(self):
        """Pulisce l'ambiente dopo i test."""
        os.unlink(self.temp_rules_file.name)
    
    def test_create_prompt(self):
        """Testa la creazione del prompt per ChatGPT."""
        prompt = self.chatgpt_analyzer._create_prompt(self.test_movement_data, "squat")
        
        # Verifica che il prompt contenga elementi chiave
        self.assertIn("Keypoints principali", prompt)
        self.assertIn("Angoli articolari calcolati", prompt)
        self.assertIn("squat", prompt.lower())
        self.assertIn("LEFT_KNEE: 85.0", prompt)
        self.assertIn("RIGHT_KNEE: 85.0", prompt)
        
        # Verifica che contenga le regole biomeccaniche
        self.assertIn("knee_angle_range", prompt)
        self.assertIn("Ginocchia che collassano internamente", prompt)
    
    @patch('openai.AsyncOpenAI.chat.completions.create')
    async def test_analyze_movement_with_mock(self, mock_create):
        """Testa l'analisi del movimento con mock dell'API OpenAI."""
        # Configura il mock per simulare la risposta dell'API
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message = MagicMock()
        mock_response.choices[0].message.content = json.dumps({
            "exercise_identified": "squat",
            "is_correct": True,
            "errors_detected": [],
            "feedback": "L'esecuzione dello squat è corretta.",
            "suggestions": ["Continua così, ottimo lavoro!"]
        })
        
        mock_create.return_value = mock_response
        
        # Analizza il movimento
        result = await self.chatgpt_analyzer.analyze_movement(self.test_movement_data, "squat")
        
        # Verifica che il risultato contenga i dati attesi
        self.assertIn('feedback', result)
        self.assertIn('raw_response', result)
        self.assertIn('generated_at', result)
        
        # Verifica che il feedback sia strutturato correttamente
        feedback = result['feedback']
        self.assertEqual(feedback['exercise_identified'], "squat")
        self.assertTrue(feedback['is_correct'])
        self.assertEqual(len(feedback['errors_detected']), 0)
        self.assertIn("corretta", feedback['feedback'])
        self.assertEqual(len(feedback['suggestions']), 1)


class TestMovementAnalysisService(unittest.TestCase):
    """Test per il servizio MovementAnalysisService."""
    
    def setUp(self):
        """Inizializza l'ambiente di test."""
        # Mock della sessione database
        self.mock_db_session = MagicMock()
        
        # Inizializza il servizio con mock
        self.service = MovementAnalysisService(
            db_session=self.mock_db_session,
            openai_api_key="test_key",  # Chiave fittizia per i test
            biomechanical_rules_file=None  # Usa regole predefinite
        )
        
        # Patch dei metodi interni
        self.video_processor_patch = patch.object(self.service.video_processor, 'process_frame')
        self.mock_video_processor = self.video_processor_patch.start()
        
        self.chatgpt_analyzer_patch = patch.object(self.service.chatgpt_analyzer, 'analyze_movement')
        self.mock_chatgpt_analyzer = self.chatgpt_analyzer_patch.start()
        
        # Configura i mock
        self.mock_video_processor.return_value = {
            "keypoints": {"NOSE": {"x": 0.5, "y": 0.2, "z": 0.0, "visibility": 0.9}},
            "calculated_angles": {"LEFT_KNEE": 85.0},
            "timestamp": 1621234567.89
        }
        
        self.mock_chatgpt_analyzer.return_value = {
            "feedback": {
                "exercise_identified": "squat",
                "is_correct": True,
                "errors_detected": [],
                "feedback": "L'esecuzione dello squat è corretta.",
                "suggestions": ["Continua così, ottimo lavoro!"]
            },
            "raw_response": "...",
            "generated_at": "2023-01-01T12:00:00",
            "processing_time": 1.5
        }
    
    def tearDown(self):
        """Pulisce l'ambiente dopo i test."""
        self.video_processor_patch.stop()
        self.chatgpt_analyzer_patch.stop()
        self.service.release()
    
    async def test_start_session(self):
        """Testa l'avvio di una sessione."""
        result = await self.service.start_session(user_id=1, exercise_hint="squat")
        
        # Verifica che il risultato contenga l'ID sessione
        self.assertIn('session_id', result)
        
        # Verifica che la sessione sia stata creata internamente
        session_id = result['session_id']
        self.assertIn(session_id, self.service.active_sessions)
        
        # Verifica che la sessione contenga i dati corretti
        session = self.service.active_sessions[session_id]
        self.assertEqual(session['user_id'], 1)
        self.assertEqual(session['exercise_hint'], "squat")
        self.assertEqual(len(session['frames']), 0)
    
    async def test_process_frame(self):
        """Testa il processamento di un frame."""
        # Avvia una sessione
        start_result = await self.service.start_session(user_id=1, exercise_hint="squat")
        session_id = start_result['session_id']
        
        # Processa un frame
        frame_data = b'test_frame_data'  # Dati fittizi
        result = await self.service.process_frame(session_id, frame_data)
        
        # Verifica che il risultato sia corretto
        self.assertEqual(result['session_id'], session_id)
        self.assertTrue(result['frame_processed'])
        self.assertEqual(result['frame_index'], 0)
        
        # Verifica che il frame sia stato salvato nella sessione
        session = self.service.active_sessions[session_id]
        self.assertEqual(len(session['frames']), 1)
    
    async def test_complete_session(self):
        """Testa il completamento di una sessione."""
        # Avvia una sessione
        start_result = await self.service.start_session(user_id=1, exercise_hint="squat")
        session_id = start_result['session_id']
        
        # Processa un frame
        frame_data = b'test_frame_data'  # Dati fittizi
        await self.service.process_frame(session_id, frame_data)
        
        # Completa la sessione
        result = await self.service.complete_session(session_id)
        
        # Verifica che il risultato contenga i dati attesi
        self.assertEqual(result['session_id'], session_id)
        self.assertEqual(result['user_id'], 1)
        self.assertEqual(result['frame_count'], 1)
        self.assertEqual(result['exercise_identified'], "squat")
        self.assertTrue(result['is_correct'])
        self.assertEqual(len(result['errors_detected']), 0)
        self.assertIn("corretta", result['feedback'])
        self.assertEqual(len(result['suggestions']), 1)
        
        # Verifica che la sessione sia stata rimossa
        self.assertNotIn(session_id, self.service.active_sessions)


if __name__ == '__main__':
    unittest.main()
