#!/bin/bash

# Script di avvio unificato per Fitness Analyzer
# Questo script configura e avvia sia il backend che il frontend del sistema

echo "=== Fitness Analyzer - Script di Avvio Unificato ==="
echo "Configurazione e avvio del sistema in corso..."

# Crea directory per i log
mkdir -p logs

# Colori per output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Funzione per verificare prerequisiti
check_prerequisites() {
    echo -e "${YELLOW}Verifica prerequisiti...${NC}"
    
    # Verifica Python
    if command -v python3 >/dev/null 2>&1; then
        python_version=$(python3 --version)
        echo -e "${GREEN}✓ Python installato: $python_version${NC}"
    else
        echo -e "${RED}✗ Python 3 non trovato. Installare Python 3.8+ per continuare.${NC}"
        exit 1
    fi
    
    # Verifica pip
    if command -v pip3 >/dev/null 2>&1; then
        pip_version=$(pip3 --version)
        echo -e "${GREEN}✓ Pip installato: $pip_version${NC}"
    else
        echo -e "${RED}✗ Pip non trovato. Installare pip per continuare.${NC}"
        exit 1
    fi
    
    # Verifica Node.js
    if command -v node >/dev/null 2>&1; then
        node_version=$(node --version)
        echo -e "${GREEN}✓ Node.js installato: $node_version${NC}"
    else
        echo -e "${RED}✗ Node.js non trovato. Installare Node.js 14+ per continuare.${NC}"
        exit 1
    fi
    
    # Verifica npm
    if command -v npm >/dev/null 2>&1; then
        npm_version=$(npm --version)
        echo -e "${GREEN}✓ npm installato: $npm_version${NC}"
    else
        echo -e "${RED}✗ npm non trovato. Installare npm per continuare.${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}Tutti i prerequisiti sono soddisfatti.${NC}"
}

# Funzione per configurare l'ambiente virtuale Python
setup_python_env() {
    echo -e "${YELLOW}Configurazione ambiente Python...${NC}"
    
    cd backend
    
    # Crea ambiente virtuale se non esiste
    if [ ! -d "venv" ]; then
        echo "Creazione ambiente virtuale Python..."
        python3 -m venv venv
    fi
    
    # Attiva ambiente virtuale
    source venv/bin/activate
    
    # Installa dipendenze
    echo "Installazione dipendenze Python..."
    pip install -r requirements.txt
    
    echo -e "${GREEN}Ambiente Python configurato.${NC}"
    
    # Torna alla directory principale
    cd ..
}

# Funzione per configurare il frontend
setup_frontend() {
    echo -e "${YELLOW}Configurazione frontend...${NC}"
    
    cd frontend
    
    # Installa dipendenze
    echo "Installazione dipendenze Node.js..."
    npm install
    
    echo -e "${GREEN}Frontend configurato.${NC}"
    
    # Torna alla directory principale
    cd ..
}

# Funzione per configurare il database
setup_database() {
    echo -e "${YELLOW}Configurazione database...${NC}"
    
    cd backend
    
    # Attiva ambiente virtuale
    source venv/bin/activate
    
    # Crea directory data se non esiste
    mkdir -p data
    
    # Inizializza database SQLite
    echo "Inizializzazione database..."
    python -c "
import os
import sys
sys.path.append('.')
from src.models.database import Base
from sqlalchemy import create_engine
engine = create_engine('sqlite:///./data/fitness_analyzer.db')
Base.metadata.create_all(engine)
print('Database inizializzato con successo.')
"
    
    echo -e "${GREEN}Database configurato.${NC}"
    
    # Torna alla directory principale
    cd ..
}

# Funzione per avviare il backend
start_backend() {
    echo -e "${YELLOW}Avvio backend...${NC}"
    
    cd backend
    
    # Attiva ambiente virtuale
    source venv/bin/activate
    
    # Avvia backend in background
    echo "Avvio server FastAPI..."
    python -m uvicorn src.api.main:app --host 0.0.0.0 --port 8000 > ../logs/backend.log 2>&1 &
    BACKEND_PID=$!
    
    echo $BACKEND_PID > ../logs/backend.pid
    echo -e "${GREEN}Backend avviato (PID: $BACKEND_PID). Log: logs/backend.log${NC}"
    
    # Torna alla directory principale
    cd ..
}

# Funzione per avviare il frontend
start_frontend() {
    echo -e "${YELLOW}Avvio frontend...${NC}"
    
    cd frontend
    
    # Avvia server di sviluppo in background
    echo "Avvio server di sviluppo..."
    npm run dev > ../logs/frontend.log 2>&1 &
    FRONTEND_PID=$!
    
    echo $FRONTEND_PID > ../logs/frontend.pid
    echo -e "${GREEN}Frontend avviato (PID: $FRONTEND_PID). Log: logs/frontend.log${NC}"
    
    # Torna alla directory principale
    cd ..
}

# Funzione per fermare il sistema
stop_system() {
    echo -e "${YELLOW}Arresto del sistema in corso...${NC}"
    
    # Ferma backend
    if [ -f "logs/backend.pid" ]; then
        BACKEND_PID=$(cat logs/backend.pid)
        echo "Arresto backend (PID: $BACKEND_PID)..."
        kill $BACKEND_PID 2>/dev/null || true
        rm logs/backend.pid
    fi
    
    # Ferma frontend
    if [ -f "logs/frontend.pid" ]; then
        FRONTEND_PID=$(cat logs/frontend.pid)
        echo "Arresto frontend (PID: $FRONTEND_PID)..."
        kill $FRONTEND_PID 2>/dev/null || true
        rm logs/frontend.pid
    fi
    
    echo -e "${GREEN}Sistema arrestato.${NC}"
}

# Funzione per mostrare lo stato del sistema
show_status() {
    echo -e "${YELLOW}Stato del sistema:${NC}"
    
    # Controlla backend
    if [ -f "logs/backend.pid" ]; then
        BACKEND_PID=$(cat logs/backend.pid)
        if ps -p $BACKEND_PID > /dev/null; then
            echo -e "${GREEN}✓ Backend in esecuzione (PID: $BACKEND_PID)${NC}"
        else
            echo -e "${RED}✗ Backend non in esecuzione (PID obsoleto: $BACKEND_PID)${NC}"
        fi
    else
        echo -e "${RED}✗ Backend non in esecuzione${NC}"
    fi
    
    # Controlla frontend
    if [ -f "logs/frontend.pid" ]; then
        FRONTEND_PID=$(cat logs/frontend.pid)
        if ps -p $FRONTEND_PID > /dev/null; then
            echo -e "${GREEN}✓ Frontend in esecuzione (PID: $FRONTEND_PID)${NC}"
        else
            echo -e "${RED}✗ Frontend non in esecuzione (PID obsoleto: $FRONTEND_PID)${NC}"
        fi
    else
        echo -e "${RED}✗ Frontend non in esecuzione${NC}"
    fi
    
    # Mostra URL
    echo -e "${YELLOW}URL:${NC}"
    echo -e "Backend API: ${GREEN}http://localhost:8000${NC}"
    echo -e "Frontend: ${GREEN}http://localhost:5173${NC}"
}

# Funzione per mostrare l'aiuto
show_help() {
    echo "Utilizzo: $0 [opzione]"
    echo ""
    echo "Opzioni:"
    echo "  start       Avvia il sistema completo"
    echo "  stop        Ferma il sistema"
    echo "  restart     Riavvia il sistema"
    echo "  status      Mostra lo stato del sistema"
    echo "  setup       Configura l'ambiente senza avviare il sistema"
    echo "  help        Mostra questo messaggio di aiuto"
    echo ""
    echo "Esempio: $0 start"
}

# Gestione argomenti
case "$1" in
    start)
        check_prerequisites
        setup_python_env
        setup_frontend
        setup_database
        start_backend
        start_frontend
        show_status
        echo -e "${GREEN}Sistema avviato con successo!${NC}"
        echo -e "Apri ${YELLOW}http://localhost:5173${NC} nel tuo browser per accedere all'applicazione."
        ;;
    stop)
        stop_system
        ;;
    restart)
        stop_system
        sleep 2
        check_prerequisites
        setup_python_env
        setup_frontend
        start_backend
        start_frontend
        show_status
        echo -e "${GREEN}Sistema riavviato con successo!${NC}"
        echo -e "Apri ${YELLOW}http://localhost:5173${NC} nel tuo browser per accedere all'applicazione."
        ;;
    status)
        show_status
        ;;
    setup)
        check_prerequisites
        setup_python_env
        setup_frontend
        setup_database
        echo -e "${GREEN}Configurazione completata. Usa '$0 start' per avviare il sistema.${NC}"
        ;;
    help|*)
        show_help
        ;;
esac

exit 0
