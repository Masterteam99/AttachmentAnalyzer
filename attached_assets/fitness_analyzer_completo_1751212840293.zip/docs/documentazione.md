# Documentazione del Prototipo Fitness Analyzer

## Panoramica del Sistema

Il Fitness Analyzer è un sistema integrato per l'analisi del movimento che combina le migliori caratteristiche del Software Manu e del Software Claud, con l'aggiunta di un innovativo approccio basato su ChatGPT come analizzatore centrale.

Il sistema è progettato per:
- Acquisire video dell'utente che esegue esercizi fisici
- Estrarre keypoints 3D tramite MediaPipe
- Analizzare il movimento utilizzando ChatGPT come analizzatore centrale
- Fornire feedback personalizzati in linguaggio naturale
- Archiviare dati e feedback per analisi future

## Architettura del Sistema

### Frontend
- Interfaccia web responsive per acquisizione video e visualizzazione feedback
- Implementato con HTML, CSS e JavaScript
- Supporto per WebRTC per accesso alla webcam
- Visualizzazione in tempo reale dei keypoints

### Backend
- API REST e WebSocket per comunicazione in tempo reale
- Implementato con FastAPI e SQLAlchemy
- Integrazione con MediaPipe per estrazione keypoints
- Integrazione con API ChatGPT per analisi del movimento
- Sistema di persistenza dati per sessioni e feedback

## Componenti Principali

### VideoProcessor
Responsabile dell'estrazione dei keypoints 3D dal video utilizzando MediaPipe Pose.

Funzionalità:
- Estrazione keypoints 3D
- Calcolo angoli articolari
- Normalizzazione dei dati
- Generazione frame annotati

### ChatGPTAnalyzer
Analizza i dati di movimento utilizzando l'API ChatGPT.

Funzionalità:
- Generazione prompt strutturati
- Integrazione con regole biomeccaniche
- Analisi autonoma del movimento
- Generazione feedback personalizzati

### MovementAnalysisService
Servizio principale che coordina l'intero flusso di analisi.

Funzionalità:
- Gestione sessioni di analisi
- Coordinamento tra VideoProcessor e ChatGPTAnalyzer
- Salvataggio dati e feedback
- Esportazione dati in CSV e JSON

## Flusso Operativo

1. L'utente avvia una sessione di analisi tramite l'interfaccia web
2. Il sistema accede alla webcam e inizia a catturare il movimento
3. MediaPipe estrae i keypoints 3D in tempo reale
4. I dati vengono inviati a ChatGPT insieme a riferimenti biomeccanici
5. ChatGPT analizza il movimento, identifica l'esercizio e genera feedback
6. Il feedback viene presentato all'utente in modo chiaro e strutturato
7. I dati e il feedback vengono salvati per riferimento futuro

## Requisiti di Sistema

### Backend
- Python 3.11+
- FastAPI, SQLAlchemy, OpenAI SDK, MediaPipe
- Database (SQLite per sviluppo, PostgreSQL per produzione)
- Redis per comunicazione in tempo reale

### Frontend
- Browser moderno con supporto WebRTC
- Connessione internet stabile
- Webcam o dispositivo di acquisizione video

## Installazione e Configurazione

### Backend
1. Clonare il repository
2. Installare le dipendenze: `pip install -r requirements.txt`
3. Configurare le variabili d'ambiente nel file `.env`
4. Avviare il server: `uvicorn src.api.main:app --host 0.0.0.0 --port 8000`

### Frontend
1. Navigare nella directory frontend
2. Aprire `public/index.html` in un browser o servire con un server web

## Utilizzo

1. Accedere all'interfaccia web
2. Premere "Inizia Analisi" per avviare la webcam
3. Eseguire l'esercizio davanti alla webcam
4. Premere "Analizza" per ricevere feedback
5. Visualizzare il feedback dettagliato e i suggerimenti

## Limitazioni Attuali e Sviluppi Futuri

### Limitazioni
- Richiede buone condizioni di illuminazione
- Analisi ottimale per un sottoinsieme di esercizi comuni
- Richiede connessione internet per l'API ChatGPT

### Sviluppi Futuri
- Supporto per più esercizi e varianti
- Analisi di sequenze complete di allenamento
- Modalità offline con modelli locali
- App mobile nativa
- Integrazione con dispositivi wearable

## Risoluzione Problemi

### Problemi Comuni
- **Nessun keypoint rilevato**: Migliorare l'illuminazione e assicurarsi che l'intero corpo sia visibile
- **Analisi lenta**: Verificare la connessione internet e ridurre la risoluzione video
- **Errori API**: Verificare la chiave API OpenAI nel file `.env`

## Contatti e Supporto

Per assistenza tecnica o segnalazione bug, contattare il team di sviluppo.

---

© 2025 Fitness Analyzer Team
