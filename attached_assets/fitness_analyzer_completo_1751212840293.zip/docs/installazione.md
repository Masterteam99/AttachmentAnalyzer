# Guida all'Installazione e Utilizzo di Fitness Analyzer

Questa guida fornisce istruzioni dettagliate per installare, configurare e utilizzare il sistema Fitness Analyzer completo.

## Requisiti di Sistema

### Software Necessario
- **Python 3.8+**
- **Node.js 14+** e npm
- **Browser moderno** (Chrome, Firefox, Edge)
- **Webcam** funzionante

### Hardware Consigliato
- CPU: 4+ core
- RAM: 8+ GB
- Spazio su disco: 1+ GB
- Webcam con risoluzione 720p o superiore

## Installazione

### 1. Estrazione del Pacchetto
Estrarre il contenuto del file ZIP in una directory a scelta:
```
unzip fitness_analyzer_package.zip -d /percorso/desiderato/
cd /percorso/desiderato/fitness_analyzer_package/
```

### 2. Configurazione Iniziale
Eseguire lo script di configurazione che preparerà l'ambiente senza avviare il sistema:
```
chmod +x scripts/start.sh
./scripts/start.sh setup
```

Questo comando:
- Verifica i prerequisiti software
- Crea un ambiente virtuale Python
- Installa le dipendenze Python
- Configura il frontend
- Inizializza il database

### 3. Configurazione API OpenAI (Opzionale)
Per utilizzare l'analisi ChatGPT reale anziché il mock:

1. Creare un file `.env` nella directory `backend`:
```
cd backend
touch .env
```

2. Aggiungere la chiave API OpenAI al file `.env`:
```
OPENAI_API_KEY=your-api-key-here
OPENAI_MODEL=gpt-4
```

## Avvio del Sistema

### Avvio Completo
Per avviare sia il backend che il frontend:
```
./scripts/start.sh start
```

Questo comando:
- Avvia il server backend (FastAPI) sulla porta 8000
- Avvia il server di sviluppo frontend sulla porta 5173
- Mostra gli URL per accedere all'applicazione

### Verifica dello Stato
Per verificare lo stato del sistema:
```
./scripts/start.sh status
```

### Arresto del Sistema
Per arrestare tutti i componenti:
```
./scripts/start.sh stop
```

### Riavvio del Sistema
Per riavviare il sistema:
```
./scripts/start.sh restart
```

## Utilizzo del Sistema

### Accesso all'Applicazione
1. Aprire il browser e navigare a: `http://localhost:5173`
2. L'interfaccia principale mostrerà l'area video e l'area feedback

### Analisi del Movimento
1. Cliccare su "Inizia Analisi" per avviare la webcam
2. Posizionarsi in modo che il corpo sia completamente visibile
3. Eseguire uno degli esercizi supportati (squat, push-up, lunge)
4. Cliccare su "Analizza" per ricevere feedback
5. Visualizzare il feedback dettagliato e i suggerimenti

### Esercizi Supportati
- **Squat**: Posizionarsi frontalmente, piedi alla larghezza delle spalle
- **Push-up**: Posizionarsi lateralmente, corpo in linea retta
- **Lunge**: Posizionarsi lateralmente, un passo avanti con una gamba

## Struttura del Progetto

```
fitness_analyzer_package/
├── backend/               # Server backend
│   ├── requirements.txt   # Dipendenze Python
│   ├── src/               # Codice sorgente backend
│   │   ├── api/           # API REST e WebSocket
│   │   ├── config/        # Configurazioni
│   │   ├── models/        # Modelli database
│   │   └── services/      # Servizi (MediaPipe, ChatGPT)
│   └── tests/             # Test unitari e di integrazione
├── frontend/              # Client frontend
│   ├── package.json       # Dipendenze Node.js
│   └── public/            # File statici
├── docs/                  # Documentazione
│   └── documentazione.md  # Documentazione dettagliata
└── scripts/               # Script di utilità
    └── start.sh           # Script di avvio unificato
```

## Risoluzione Problemi

### Backend non si avvia
- Verificare che la porta 8000 non sia già in uso
- Controllare i log in `logs/backend.log`
- Verificare che tutte le dipendenze siano installate correttamente

### Frontend non si avvia
- Verificare che la porta 5173 non sia già in uso
- Controllare i log in `logs/frontend.log`
- Verificare che Node.js e npm siano installati correttamente

### Webcam non funziona
- Verificare che il browser abbia i permessi di accesso alla webcam
- Provare con un browser diverso (Chrome consigliato)
- Verificare che la webcam funzioni con altre applicazioni

### Analisi non funziona
- Verificare che il backend sia in esecuzione
- Controllare la connessione tra frontend e backend
- Se si utilizza l'API OpenAI, verificare che la chiave API sia valida

## Personalizzazione

### Regole Biomeccaniche
Le regole biomeccaniche possono essere modificate nel file:
```
backend/src/services/chatgpt_analyzer.py
```

### Interfaccia Utente
L'interfaccia utente può essere personalizzata modificando i file nella directory:
```
frontend/public/
```

## Supporto e Contatti

Per assistenza tecnica o segnalazione bug, contattare il team di sviluppo.

---

© 2025 Fitness Analyzer Team
