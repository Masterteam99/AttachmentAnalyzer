# Istruzioni per l'Utilizzo di Fitness Analyzer (Versione All-in-One)

## Panoramica

Questa è una versione "all-in-one" del sistema Fitness Analyzer, contenuta in un singolo file HTML. Questa versione è stata creata per facilitare la visualizzazione e il test del sistema su qualsiasi portale o ambiente web, senza necessità di configurare un server backend o API esterne.

## Requisiti di Sistema

- **Browser moderno** con supporto a WebRTC e JavaScript ES6
  - Chrome 79+ (consigliato)
  - Firefox 76+
  - Edge 79+
  - Safari 14.1+
- **Webcam** funzionante e accessibile
- **Connessione Internet** per il caricamento delle librerie MediaPipe da CDN

## Come Utilizzare

1. **Apertura del File**:
   - Apri il file `fitness_analyzer_all_in_one.html` in un browser moderno
   - In alternativa, carica il file su un server web o hosting statico

2. **Avvio dell'Analisi**:
   - Clicca sul pulsante "Inizia Analisi" per avviare la webcam
   - Concedi i permessi di accesso alla webcam quando richiesto
   - Posizionati in modo che il tuo corpo sia completamente visibile

3. **Esecuzione dell'Esercizio**:
   - Esegui uno degli esercizi supportati (squat, push-up, lunge)
   - Mantieni una posizione in cui sei completamente visibile
   - Assicurati di avere una buona illuminazione

4. **Analisi del Movimento**:
   - Clicca sul pulsante "Analizza" per ricevere feedback
   - Attendi qualche secondo per l'elaborazione
   - Visualizza il feedback dettagliato e i suggerimenti

5. **Terminare la Sessione**:
   - Clicca sul pulsante "Ferma" per interrompere l'accesso alla webcam
   - Chiudi la finestra del browser per terminare completamente

## Esercizi Supportati

1. **Squat**:
   - Posizionati frontalmente alla webcam
   - Piedi alla larghezza delle spalle
   - Scendi piegando le ginocchia come se dovessi sederti
   - Mantieni la schiena dritta

2. **Push-up**:
   - Posizionati lateralmente alla webcam
   - Mani a terra alla larghezza delle spalle
   - Corpo in linea retta
   - Piega i gomiti per scendere e poi risali

3. **Lunge**:
   - Posizionati lateralmente alla webcam
   - Fai un passo avanti con una gamba
   - Piega entrambe le ginocchia a circa 90 gradi
   - Mantieni il busto eretto

## Limitazioni della Versione All-in-One

1. **Analisi Semplificata**:
   - Questa versione utilizza un mock dell'API ChatGPT con regole predefinite
   - L'analisi è limitata a pattern di movimento specifici
   - Il feedback è generato da regole statiche, non da un'AI reale

2. **Supporto Limitato agli Esercizi**:
   - Solo squat, push-up e lunge sono analizzati in dettaglio
   - Altri esercizi potrebbero essere riconosciuti ma con feedback generico

3. **Nessuna Persistenza Dati**:
   - I dati non vengono salvati tra le sessioni
   - Non è possibile visualizzare lo storico delle analisi

4. **Performance**:
   - L'elaborazione avviene interamente nel browser
   - Dispositivi meno potenti potrebbero riscontrare rallentamenti
   - La qualità dell'analisi dipende dalle prestazioni del dispositivo

5. **Dipendenze Esterne**:
   - Richiede accesso a Internet per caricare le librerie MediaPipe
   - Potrebbe non funzionare in ambienti con restrizioni di rete

## Risoluzione Problemi

- **Webcam non si avvia**: Verifica che il browser abbia i permessi di accesso alla webcam
- **MediaPipe non carica**: Assicurati di avere una connessione Internet attiva
- **Nessun keypoint rilevato**: Migliora l'illuminazione e assicurati di essere completamente visibile
- **Browser non supportato**: Prova con Chrome o Edge per la massima compatibilità
- **Analisi lenta**: Chiudi altre applicazioni e schede del browser per liberare risorse

## Note Tecniche

Questa versione all-in-one include:
- MediaPipe Pose per l'estrazione dei keypoints 3D
- Algoritmi di calcolo degli angoli articolari
- Mock dell'analisi ChatGPT con regole biomeccaniche predefinite
- Interfaccia utente responsive per visualizzazione feedback

Per una versione completa con backend, database e integrazione reale con ChatGPT, è necessario implementare il sistema completo come descritto nella documentazione principale.
