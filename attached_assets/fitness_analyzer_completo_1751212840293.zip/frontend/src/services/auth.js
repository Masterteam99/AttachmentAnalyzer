import { api } from './api'

export const authService = {
  async login(email, password) {
    const formData = new FormData()
    formData.append('username', email)
    formData.append('password', password)
    
    const response = await api.post('/token', formData)
    return response.data
  },
  
  async register(userData) {
    const response = await api.post('/register', userData)
    return response.data
  },
  
  async getProfile() {
    const response = await api.get('/users/me')
    return response.data
  }
}
